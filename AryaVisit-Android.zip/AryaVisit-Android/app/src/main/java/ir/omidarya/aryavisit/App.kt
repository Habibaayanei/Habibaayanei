package ir.omidarya.aryavisit

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        // Persian locale => RTL for dialogs and native widgets
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags("fa"))
    }
}
