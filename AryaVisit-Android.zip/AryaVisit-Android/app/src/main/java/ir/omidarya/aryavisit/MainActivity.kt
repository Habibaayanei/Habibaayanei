package ir.omidarya.aryavisit

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.text.InputType
import android.util.Base64
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.addCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var progress: ProgressBar
    private lateinit var errorView: LinearLayout
    private lateinit var errorText: TextView

    private var serverUrl = ""
    private var loadFailed = false
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    private val chooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val uris = WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data)
        fileCallback?.onReceiveValue(uris)
        fileCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        web = findViewById(R.id.web)
        swipe = findViewById(R.id.swipe)
        progress = findViewById(R.id.progress)
        errorView = findViewById(R.id.errorView)
        errorText = findViewById(R.id.errorText)

        findViewById<Button>(R.id.retryBtn).setOnClickListener { retry() }
        findViewById<Button>(R.id.changeServerBtn).setOnClickListener { showServerDialog(cancelable = true) }

        swipe.setColorSchemeResources(R.color.orange, R.color.navy)
        swipe.setOnRefreshListener { retry(); swipe.isRefreshing = false }
        swipe.setOnChildScrollUpCallback { _, _ -> web.scrollY > 0 }

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            setSupportZoom(false)
            builtInZoomControls = false
        }
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        web.webViewClient = client
        web.webChromeClient = chrome

        onBackPressedDispatcher.addCallback(this) {
            if (errorView.visibility != View.VISIBLE && web.canGoBack()) web.goBack() else finish()
        }

        serverUrl = getSharedPreferences("arya", MODE_PRIVATE).getString("serverUrl", "") ?: ""
        if (serverUrl.isBlank()) showServerDialog(cancelable = false) else web.loadUrl(serverUrl)
    }

    // ---------------- WebView clients ----------------

    private val client = object : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            val target = request.url
            val host = Uri.parse(serverUrl).host
            if (target.host == host) return false
            try { startActivity(Intent(Intent.ACTION_VIEW, target)) } catch (_: Exception) {}
            return true
        }

        override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
            progress.visibility = View.VISIBLE
        }

        override fun onPageFinished(view: WebView, url: String?) {
            progress.visibility = View.GONE
            if (!loadFailed) errorView.visibility = View.GONE
            view.evaluateJavascript(DOWNLOAD_PATCH_JS, null)
        }

        override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
            if (request.isForMainFrame) {
                loadFailed = true
                errorText.text = "اتصال به سرور آریاویزیت برقرار نشد.\n\nآدرس فعلی:\n$serverUrl\n\nمطمئن شوید سرور روشن است و گوشی به همان شبکه (یا اینترنت) متصل است."
                errorView.visibility = View.VISIBLE
            }
        }
    }

    private val chrome = object : WebChromeClient() {
        override fun onProgressChanged(view: WebView, newProgress: Int) {
            progress.progress = newProgress
        }

        override fun onShowFileChooser(
            webView: WebView,
            callback: ValueCallback<Array<Uri>>,
            params: FileChooserParams
        ): Boolean {
            fileCallback?.onReceiveValue(null)
            fileCallback = callback
            return try {
                chooser.launch(params.createIntent())
                true
            } catch (e: Exception) {
                fileCallback = null
                callback.onReceiveValue(null)
                false
            }
        }

        override fun onJsAlert(view: WebView, url: String?, message: String?, result: JsResult): Boolean {
            AlertDialog.Builder(this@MainActivity).setMessage(message).setCancelable(false)
                .setPositiveButton("تأیید") { _, _ -> result.confirm() }.show()
            return true
        }

        override fun onJsConfirm(view: WebView, url: String?, message: String?, result: JsResult): Boolean {
            AlertDialog.Builder(this@MainActivity).setMessage(message).setCancelable(false)
                .setPositiveButton("تأیید") { _, _ -> result.confirm() }
                .setNegativeButton("انصراف") { _, _ -> result.cancel() }.show()
            return true
        }

        override fun onJsPrompt(
            view: WebView, url: String?, message: String?, defaultValue: String?, result: JsPromptResult
        ): Boolean {
            val input = EditText(this@MainActivity).apply { setText(defaultValue ?: "") }
            val box = FrameLayout(this@MainActivity).apply { setPadding(48, 16, 48, 0); addView(input) }
            AlertDialog.Builder(this@MainActivity).setMessage(message).setView(box).setCancelable(false)
                .setPositiveButton("تأیید") { _, _ -> result.confirm(input.text.toString()) }
                .setNegativeButton("انصراف") { _, _ -> result.cancel() }.show()
            return true
        }
    }

    // ---------------- Retry / server setup ----------------

    private fun retry() {
        if (serverUrl.isBlank()) { showServerDialog(false); return }
        loadFailed = false
        errorView.visibility = View.GONE
        web.loadUrl(serverUrl)
    }

    private fun applyServer(url: String) {
        getSharedPreferences("arya", MODE_PRIVATE).edit().putString("serverUrl", url).apply()
        serverUrl = url
        web.clearHistory()
        retry()
    }

    private fun normalize(raw: String): String? {
        var s = raw.trim()
        if (s.isEmpty()) return null
        if (!s.startsWith("http://") && !s.startsWith("https://")) s = "http://$s"
        s = s.trimEnd('/')
        return if (Uri.parse(s).host.isNullOrBlank()) null else s
    }

    private fun ping(url: String): Boolean = try {
        val c = URL("$url/api/health").openConnection() as HttpURLConnection
        c.connectTimeout = 5000; c.readTimeout = 5000
        val ok = c.responseCode == 200
        c.disconnect(); ok
    } catch (_: Exception) { false }

    private fun showServerDialog(cancelable: Boolean) {
        val input = EditText(this).apply {
            hint = "مثال: 192.168.1.10:8080"
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            textDirection = View.TEXT_DIRECTION_LTR
            textAlignment = View.TEXT_ALIGNMENT_VIEW_START
            setText(serverUrl)
        }
        val box = FrameLayout(this).apply { setPadding(48, 16, 48, 0); addView(input) }
        val builder = AlertDialog.Builder(this)
            .setTitle("آدرس سرور آریاویزیت")
            .setMessage("آدرس کامپیوتری که برنامه روی آن اجراست را وارد کنید (همان آدرسی که در مرورگر باز می‌کنید).")
            .setView(box)
            .setCancelable(cancelable)
            .setPositiveButton("اتصال", null)
            .setNeutralButton("ذخیره بدون آزمایش", null)
        if (cancelable) builder.setNegativeButton("انصراف", null)
        val dlg = builder.create()
        dlg.setOnShowListener {
            val connect = dlg.getButton(AlertDialog.BUTTON_POSITIVE)
            connect.setOnClickListener {
                val url = normalize(input.text.toString())
                if (url == null) { input.error = "آدرس معتبر نیست"; return@setOnClickListener }
                connect.isEnabled = false
                thread {
                    val ok = ping(url)
                    runOnUiThread {
                        connect.isEnabled = true
                        if (ok) { applyServer(url); dlg.dismiss() }
                        else input.error = "اتصال به سرور برقرار نشد"
                    }
                }
            }
            dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                val url = normalize(input.text.toString())
                if (url == null) { input.error = "آدرس معتبر نیست"; return@setOnClickListener }
                applyServer(url); dlg.dismiss()
            }
        }
        dlg.show()
    }

    // ---------------- File download bridge (backup JSON etc.) ----------------

    inner class Bridge {
        @JavascriptInterface
        fun saveFile(base64: String, name: String, mime: String) {
            thread {
                try {
                    val bytes = Base64.decode(base64, Base64.DEFAULT)
                    val safe = name.replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "AryaVisit-file" }
                    saveToDownloads(bytes, safe, mime.ifBlank { "application/octet-stream" })
                    runOnUiThread { Toast.makeText(this@MainActivity, "فایل در پوشه Downloads ذخیره شد: $safe", Toast.LENGTH_LONG).show() }
                } catch (e: Exception) {
                    runOnUiThread { Toast.makeText(this@MainActivity, "ذخیره فایل ناموفق بود", Toast.LENGTH_LONG).show() }
                }
            }
        }
    }

    private fun saveToDownloads(bytes: ByteArray, name: String, mime: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("insert failed")
            contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
        } else {
            val dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: filesDir
            File(dir, name).writeBytes(bytes)
        }
    }

    override fun onDestroy() {
        fileCallback?.onReceiveValue(null)
        web.removeJavascriptInterface("AndroidBridge")
        super.onDestroy()
    }

    companion object {
        // The web app downloads via blob: <a download>, which WebView ignores. Route it to the native bridge.
        private const val DOWNLOAD_PATCH_JS = """
(function(){
  if(window.__aryaPatched)return; window.__aryaPatched=true;
  var blobs=new Map(), oc=URL.createObjectURL;
  URL.createObjectURL=function(b){var u=oc.call(URL,b);blobs.set(u,b);return u;};
  var origClick=HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click=function(){
    var a=this;
    if(a.href&&a.href.indexOf('blob:')===0&&a.download&&blobs.has(a.href)){
      var b=blobs.get(a.href), name=a.download, fr=new FileReader();
      fr.onloadend=function(){ AndroidBridge.saveFile(String(fr.result).split(',')[1]||'', name, b.type||''); };
      fr.readAsDataURL(b);
      return;
    }
    return origClick.apply(a,arguments);
  };
})();
"""
    }
}
